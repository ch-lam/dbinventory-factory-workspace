-- exit in case of failure on any SQL command during installation
WHENEVER SQLERROR EXIT SQL.SQLCODE

-- force deployment with DBINVENTORY schema (to avoid SYS/SYSTEM deployment in wrong place)
alter session set current_schema = DBINVENTORY;

-- Deploys schema
@V__001_create_schema.sql
-- @V__009_initial_data.sql

